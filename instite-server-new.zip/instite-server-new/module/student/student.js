const client = require('../../connection/connection')
client.connect();



const loginAdmin = (req, res, next) => {
    const { username, password } = req.body;

    let checkSql = `select count(1) from admin_login where adminnumber='${username}' and adminpassword='${password}'`
    client.query(checkSql).then((checkData) => {
       
    console.log(checkData,"checkdata")
        if (checkData.rows[0].count > 0) {
          
            res.status(200).send({ data: [], message: "Login successfully", status: true })
        } else {
            res.status(200).send({ message: "Invalid Credentials", status: false, data: [] });
          
        }
    }).catch((error) => {
        console.log(error,"catch")
        res.status(400).send({ message: "Login Failed", status: false, data: [] });
       
    });
    client.end;
};





const addStudent = (req, res, next) => {
    res.json({ message: "POST new student" });
};


const updateStudent = (req, res, next) => {
    res.json({ message: "POST new student" });
};

const getStudent = (req, res, next) => {
    res.json({ message: "POST new student" });
}

const deleteStudent = (req, res, next) => {
    res.json({ message: "POST new student" });
};

module.exports = { addStudent, updateStudent, getStudent, deleteStudent,loginAdmin };