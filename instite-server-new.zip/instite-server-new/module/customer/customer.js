const addcustomerPayment = (req, res, next) => {
    res.json({message: "POST new student"});
};

const updatecustomerPayment = (req, res, next) => {
    res.json({message: "POST new student"}); 
};

const getcustomerPayment = (req, res, next) => {
    res.json({message: "POST new customer"}); 
}

const deletecustomerPayment = (req, res, next) => {
    res.json({message: "POST new student"});
};

module.exports ={ addcustomerPayment,updatecustomerPayment,getcustomerPayment,deletecustomerPayment };