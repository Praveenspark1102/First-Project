const addstudentPayment = (req, res, next) => {
    res.json({message: "POST new student"});
};

const updatestudentPayment = (req, res, next) => {
    res.json({message: "POST new student"}); 
};

const getstudentPayment = (req, res, next) => {
    res.json({message: "POST new payment"}); 
}

const deletestudentPayment = (req, res, next) => {
    res.json({message: "POST new student"});
};

module.exports ={ addstudentPayment,updatestudentPayment,getstudentPayment,deletestudentPayment };