const express = require('express');
const router  = express.Router(); 
const { addStudent,deleteStudent,getStudent,updateStudent, loginAdmin } = require('./module/student/student');
const {addstudentPayment, deletestudentPayment, getstudentPayment,updatestudentPayment,} =require('./module/payment/payment')
const {addcustomerPayment,deletecustomerPayment,getcustomerPayment,updatecustomerPayment}=require('./module/customer/customer')



//student
router.post('/api/addStudent',addStudent); 
router.post('/api/deleteStudent',deleteStudent);   
router.post('/api/getStudent',getStudent); 
router.post('/api/updateStudent',updateStudent);
router.post('/api/loginAdmin',loginAdmin) 


//student payment
router.post('/api/addstudentPayment',addstudentPayment); 
router.post('/api/deletestudentPayment',deletestudentPayment); 
router.post('/api/getstudentPayment',getstudentPayment); 
router.post('/api/updatestudentPayment',updatestudentPayment); 


//customer payment
router.post('/api/addcustomerPayment',addcustomerPayment); 
router.post('/api/deletecustomerPayment',deletecustomerPayment); 
router.post('/api/getcustomerPayment',getcustomerPayment); 
router.post('/api/updatecustomerPayment',updatecustomerPayment); 


module.exports = router; 

