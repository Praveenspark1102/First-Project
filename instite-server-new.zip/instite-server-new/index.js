const express = require("express")
const bodyparser = require("body-parser");
const routes =require('./router')


var app=express()

//cors
const cors = require('cors');
app.use(cors());

// Body-parser middleware
app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())



//router
app.use(express.json());
app.use('/', routes);


//Port listenning 5000

app.listen(5000, function() {
    console.log("application successfully runnning on port 5000")
 })