// import logo from './logo.svg';
// import './App.css';

function Customer() {
  return (
    <div className="App">

customer
    </div>
  );
}

export default Customer;
