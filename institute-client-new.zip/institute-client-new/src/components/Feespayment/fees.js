// import logo from './logo.svg';
// import './App.css';

function Fees() {
  return (
    <div className="App">

fees
    </div>
  );
}

export default Fees;
