import React, { useState, useEffect } from "react";
import Button from '@material-ui/core/Button';
import Checkbox from '@mui/material/Checkbox';
import Logo from "../../Logos/wms.png"
import IntegraLogo from "../../Logos/integra.png"
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import './adminlogin.scss';
import {  toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { config } from '../../utils/config';



function AdminLogin() {
  let navigate = useNavigate();
  

  const [usr,setUser] =useState([]);
  const [pwd,setPwd] =useState([]);

console.log(usr,pwd,"vinoth")


 const handleInputChange =(e) =>{ debugger
    const { id, value } = e.target;

    if (id === "user") {
      setUser(value)
    }
    if (id === "pwd") {
      setPwd(value)
    }
}



  async function LoginCheck(event) {  debugger
    
    event.preventDefault();
 
    if (usr.length === 0 || pwd.length === 0) {
      toast.error("Credentials Required");
    } else {
      const data = {
        username: usr.toUpperCase(),
        password: pwd,
      };
      try {
    
        console.log(data,"data")      
        axios.post(`${config.tools.basURL}loginAdmin`, data, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                
            },
        })



         .then((response) => {
            console.log("res111",response)
            if (response.data.status == true) {
             
                    navigate('/header');
            } else {
             
              toast.error("Invalid credentials");
            }
          })
          .catch((error) => {

              toast.error("User is not active/exist. Please contact the Application Support team for further assistance");
          });
      } catch (error) {
        console.log(error);
      }
    }
  }
  return (
   <>
         

     
    <div className="LoginPage">
  
            <header>
                <div><img src={Logo} alt="wms logo" /></div>
                <div><span>Powered By</span>
                    <img src={IntegraLogo} alt="integra logo" className="intLogo" /></div>
            </header>
            <div className="LoginPageInner">
                <div className="LoginPageInnerLeft">
                    <div className="CenterArea">
                        <h1>Workflow Management System</h1>
                       
                        <div className="fromsView">
                            <label>User Name</label>
                            <input type="text" id="user" onChange={(e) => handleInputChange(e)}></input>
                        </div>
                        <div className="fromsView">
                            <label>Password</label>
                            <input type="password" id="pwd" onChange={(e) => handleInputChange(e)}></input>
                        </div>
                        <div>
                            <Checkbox label="Remember me" />
                        </div>
                        <Button className="primary" onClick={LoginCheck}>Login</Button>
                     
                    </div>
                </div>
                <div className="LoginPageInnerRight">
                    <div className="CenterArea">
                        <h1>Panchaseelas</h1>
                        <ul>
                            <li>Customer satisfaction</li>
                            <li>People Care</li>
                            <li>Professionalism</li>
                            <li>Team Work</li>
                            <li>Excellence</li>
                        </ul>
                    </div>
                </div>
            </div>
            <footer>
                <p>©<script>document.write(new Date().getFullYear());</script>2022 | Integra Software Service Pvt. Ltd.</p>
            </footer>
        </div>
    </>
  );
}

export default AdminLogin;
