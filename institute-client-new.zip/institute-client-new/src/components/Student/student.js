// import logo from './logo.svg';
// import './App.css';

function Student() {
  return (
    <div className="App">

Student
    </div>
  );
}

export default Student;
