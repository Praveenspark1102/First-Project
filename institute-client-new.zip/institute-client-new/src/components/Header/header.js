import React from "react";
import { Routes, Route, NavLink, Outlet } from "react-router-dom";
// import TaskPage from "./component/task/taskpage";
// import TaskViewPage from "./component/viewtask/taskView";
// import Logo from "../public/images/wms.png";
import Logo from '../../Logos/wms.png'
import { useNavigate } from "react-router-dom";
function HeaderComponent() {

    let navigate = useNavigate();

    const handleClick = event => {
        navigate('/');

      };



    return <>
        <div className="containerFuild">
            <header>
                <div><img src={Logo} alt="wms logo" /></div>
                <div className="profileMenu" onClick={handleClick}>
                    <div className="Circle">T</div>
                    <div>
                        <p>Teex</p>
                        <span>profile</span>
                    </div>
                </div>
            </header>
            <div className="containerInner">
                <div className="LeftSide">
                    <ul>
                        <li> <NavLink to="/header">Task</NavLink></li>
                        <li> <NavLink to="/fees">FEES</NavLink></li>
                        <li> <NavLink to="/customer">CUSTOMER</NavLink></li>
                        

                     
                    </ul>
                </div>
                <div className="RightSide">
                    <Outlet />
                </div>
            </div>
        </div>  
    </>
}
export default HeaderComponent;