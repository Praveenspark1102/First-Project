import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, } from "react-router-dom";
import HeaderComponent from "./components/Header/header";
import Student from "./components/Student/student";
import AdminLogin from "./components/Login/adminlogin";
import Fees from "./components/Feespayment/fees";
import Customer from "./components/Customerpay/customer";
import '../src/components/Login/adminlogin.scss';




function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route exact path="/" element={<AdminLogin />} />
          <Route exact path="/header" element={<HeaderComponent />} />
          <Route element={<HeaderComponent />}>
            <Route index path="header" element={<Student />} />
            <Route path="/fees" element={<Fees />} />
            <Route path="/customer" element={<Customer />} />


          </Route>
        </Routes>
        
      </BrowserRouter>

    </div>
  );
}

export default App;




