import logo from './logo.svg';
import './App.css';
import Header from './components/header';
import RegistrationForm from './components/registerform';
import {ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function App() {
  return (
    <div className="App">
       <Header />
       <RegistrationForm />
      <ToastContainer
      position="top-center"
      autoClose={5000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover>

      </ToastContainer>
    </div>
  );
}

export default App;

