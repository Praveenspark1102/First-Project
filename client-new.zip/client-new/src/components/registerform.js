import React, { useState, useEffect } from 'react';
import './style.css';
import { toast } from 'react-toastify';
// import axios from 'axios';
function RegistrationForm() {

    const [firstName, setFirstName] = useState(null);
    const [lastName, setLastName] = useState(null);
    const [email, setEmail] = useState(null);
    const [password, setPassword] = useState(null);
    const [confirmPassword, setConfirmPassword] = useState(null);

    const [firstNameError,setfirstNameError] =useState(null);
    const [lastNameError,setlastNameError] =useState(null);
    const [emailError,setemailError] =useState(null);
    const [passwordError,setpasswordError] =useState(null);
    const [confirmPasswordError,setconfirmPasswordError] =useState(null);

    console.log(confirmPasswordError,passwordError,emailError,lastNameError,firstNameError,"total values")

    console.log(firstName, "firsttt")



    useEffect(() => {
        toast.success("innnnnn first page of the screen")
       
      }, []);



// function component(REact hooks) :   class component(react life cycle methods)
// function : class
// useState =>setState
// useEffect =>component didmount


   


const handleInputChange = (e) => { debugger
   
        const { id, value } = e.target;
        if (id === "firstName") {
            setFirstName(value);
            setfirstNameError("")
        }
        if (id === "lastName") {
            setLastName(value);
            setlastNameError("")
        }
        if (id === "email") {
            setEmail(value);
            setemailError("")
        }
        if (id === "password") {
            setPassword(value);
            setpasswordError("")
        }
        if (id === "confirmPassword") {
            setConfirmPassword(value);
            setconfirmPasswordError("")
        }

    }








    const validateFields = () => {
 debugger
        let firstNameError = "";
        let lastNameError = "";
        let emailError = "";
        let passwordError = "";
        let confirmPasswordError = "";
      
        if (!firstName) {
            firstNameError = "First Name is required";
        }
        if (!lastName) {
            lastNameError = "Last Name is required";
        }
        const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (!email || reg.test(email) === false) {
            emailError = "Correct Email is required ";
        }
        if (!password) {
            passwordError = "Password is required ";
        }
        if (!confirmPassword) {
            confirmPasswordError = "Confirm  Password is required";
        }
        if (emailError || firstNameError || passwordError || lastNameError || confirmPasswordError) {
            // this.setState({ nameError, emailError, passwordError });
            setemailError(emailError)
            setfirstNameError(firstNameError)
            setlastNameError(lastNameError)
            setpasswordError(passwordError)
            setconfirmPasswordError(confirmPasswordError)

            return false;
        }
        return true;

    }

    const handleSubmit = () => {
        debugger

        console.log(firstName, lastName, email, password, confirmPassword);
        if (validateFields()) {
          
            //Send back the form values to the parent i.e App.js
            // this.props.onSubmit([this.state]);
                
                toast.success("successfully registeredddd!!!!!!")
               

          }
          else{
           
            toast.error("All fields or manditory!!!!!!!")
          }


    }

return (
     

        <div className="form">
           
            <div className="form-body">
                <div className="username">
                    <label className="form__label" for="firstName">First Name </label>
                    <input className="form__input" type="text" value={firstName} onChange={(e) => handleInputChange(e)} id="firstName" placeholder="First Name" />
                    <span className="text-danger">{firstNameError}</span>
                </div>
                <div className="lastname">
                    <label className="form__label" for="lastName">Last Name </label>
                    <input type="text" name="" id="lastName" value={lastName} className="form__input" onChange={(e) => handleInputChange(e)} placeholder="LastName" />
                    <span className="text-danger">{lastNameError}</span>
                </div>
                <div className="email">
                    <label className="form__label" for="email">Email </label>
                    <input type="email" id="email" className="form__input" value={email} onChange={(e) => handleInputChange(e)} placeholder="Email" />
                    <span className="text-danger">{emailError}</span>
                </div>
                <div className="password">
                    <label className="form__label" for="password">Password </label>
                    <input className="form__input" type="password" id="password" value={password} onChange={(e) => handleInputChange(e)} placeholder="Password" />
                    <span className="text-danger">{passwordError}</span>
                </div>
                <div className="confirm-password">
                    <label className="form__label" for="confirmPassword">Confirm Password </label>
                    <input className="form__input" type="password" id="confirmPassword" value={confirmPassword} onChange={(e) => handleInputChange(e)} placeholder="Confirm Password" />
                    <span className="text-danger">{confirmPasswordError}</span>
                </div>
            </div>
            <div class="footer">
                <button onClick={() => handleSubmit()} type="submit" class="btn">Register</button>
            </div>
        </div>
    )
}
export default RegistrationForm;


